package com.usc.test;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.audiofx.Visualizer;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by apple on 16/4/16.
 */
public class PlayActivity extends Activity{
    private final int MY_PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    private ImageButton mStart, mPause, mNext, mBefore, mStop;
    private TextView mTextView;
    private boolean bIsPaused = false;
    private boolean bIsReleased = false;
    private MediaPlayer mMediaPlayer;
    private String audioFileName;
    private static String TAG="MUSICINFO";
    private Visualizer mVisualizer;
    private VisualizerView mVisualizerView;
    private String audioFilePath;
    private LinearLayout mLinearLayout;
    private static final float VISUALIZER_HEIGHT_DIP = 160f;
    private static final int BulbNum = 6;
    private String url;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        audioFilePath = getIntent().getStringExtra("audioFilePath");
        audioFileName = getIntent().getStringExtra("audioFileName");

        mMediaPlayer = new MediaPlayer();
        mStart = (ImageButton) findViewById(R.id.play_start);
        mPause = (ImageButton) findViewById(R.id.play_pause);
        mNext = (ImageButton) findViewById(R.id.play_next);
        mBefore = (ImageButton) findViewById(R.id.play_before);
        mStop = (ImageButton) findViewById(R.id.play_stop);
        mTextView = (TextView) findViewById(R.id.mText);
        mLinearLayout = (LinearLayout) findViewById(R.id.Fre);

        mTextView.setText(audioFileName);
        mStart.setOnClickListener(mStartOnClickListener);
        mBefore.setOnClickListener(mBeforeOnClickListener);
        mPause.setOnClickListener(mPauseOnClickListener);
        mNext.setOnClickListener(mNextOnClickListener);
        mStop.setOnClickListener(mStopOnClickListener);

        mStart.performClick();

        mMediaPlayer.setOnCompletionListener(mOnCompletionListener);
        mMediaPlayer.setOnErrorListener(mErrorListener);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {

                // Should we show an explanation?
                if (shouldShowRequestPermissionRationale(
                        Manifest.permission.RECORD_AUDIO)) {
                    // Explain to the user why we need to read the contacts
                }

                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                        MY_PERMISSIONS_REQUEST_RECORD_AUDIO);
                // MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
                // app-defined int constant

                return;
            }

        }

        setupVisualizerFxAndUI();
        mVisualizer.setEnabled(true);
        mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                mVisualizer.setEnabled(false);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                setVolumeControlStream(AudioManager.STREAM_SYSTEM);
            }
        });
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_RECORD_AUDIO: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted!
                    // Perform the action

                    setupVisualizerFxAndUI();
                    mVisualizer.setEnabled(true);
                    mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                        public void onCompletion(MediaPlayer mediaPlayer) {
                            mVisualizer.setEnabled(false);
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                            setVolumeControlStream(AudioManager.STREAM_SYSTEM);
                        }
                    });
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    setVolumeControlStream(AudioManager.STREAM_MUSIC);

                } else {
                    // Permission was denied
                    // :(
                    // Gracefully handle the denial
                }
                return;
            }

            // Add additional cases for other permissions you may have asked for
        }
    }


    //Set Start button action
    private OnClickListener mStartOnClickListener = new OnClickListener() {
        public void onClick(View v) {
            try {
                mMediaPlayer.reset();
                mMediaPlayer.setDataSource(audioFilePath);
                mMediaPlayer.prepare();
                mMediaPlayer.start();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    //Set Pause button action
    private OnClickListener mPauseOnClickListener = new OnClickListener() {
        public void onClick(View v) {
            if (mMediaPlayer != null) {
                if (bIsReleased == false) {
                    if (bIsPaused == false) {
                        mMediaPlayer.pause();
                        bIsPaused = true;
                        mPause.setImageResource(R.drawable.conti);
                    } else if (bIsPaused == true) {
                        mMediaPlayer.start();
                        bIsPaused = false;
                        mPause.setImageResource(R.drawable.pause);
                    }
                }
            }
        }
    };

    //Set Next button action
    private OnClickListener mNextOnClickListener = new OnClickListener() {
        public void onClick(View v) {
            try {
                if (mMediaPlayer.isPlaying() == true) {
                    mMediaPlayer.reset();
                }
                mMediaPlayer.setDataSource(audioFilePath);
                mMediaPlayer.prepare();
                mMediaPlayer.start();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    //Set Before button action
    private OnClickListener mBeforeOnClickListener = new OnClickListener() {
        public void onClick(View v) {
            if (mMediaPlayer.isPlaying() == true) {
                mMediaPlayer.reset();
            }
            try {
                mMediaPlayer.setDataSource(audioFilePath);
                mMediaPlayer.prepare();
                mMediaPlayer.start();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };

    //Set Stop button action
    private OnClickListener mStopOnClickListener = new OnClickListener() {
        public void onClick(View v) {
            if (mMediaPlayer.isPlaying() == true) {
                mMediaPlayer.reset();
            }
        }
    };

    private OnCompletionListener mOnCompletionListener = new OnCompletionListener() {
        public void onCompletion(MediaPlayer mp) {
            mMediaPlayer.reset();
        }
    };

    private OnErrorListener mErrorListener = new OnErrorListener() {
        public boolean onError(MediaPlayer mp, int what, int extra) {
            try {
                mMediaPlayer.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    };

    private void setupVisualizerFxAndUI()
    {
        mVisualizerView = new VisualizerView(this);
        mVisualizerView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.FILL_PARENT,
                (int) (VISUALIZER_HEIGHT_DIP * getResources()
                        .getDisplayMetrics().density)));
        mLinearLayout.addView(mVisualizerView);

        final int maxCR = Visualizer.getMaxCaptureRate();

        Log.d(TAG,
                "MediaPlayer audio session ID: "
                        + mMediaPlayer.getAudioSessionId());

        mVisualizer = new Visualizer(mMediaPlayer.getAudioSessionId());
        mVisualizer.setCaptureSize(256);
        mVisualizer.setDataCaptureListener(
                new Visualizer.OnDataCaptureListener() {
                    public void onWaveFormDataCapture(Visualizer visualizer,
                                                      byte[] bytes, int samplingRate) {
                        mVisualizerView.updateVisualizer(bytes);
                    }

                    public void onFftDataCapture(Visualizer visualizer,
                                                 byte[] fft, int samplingRate) {
                        mVisualizerView.updateVisualizer(fft);
                    }
                }, maxCR / 2, false, true);
    }

    @Override
    protected void onPause()
    {
        super.onPause();

        if (isFinishing() && mMediaPlayer != null)
        {
            mVisualizer.release();
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }

    /**
     * A simple class that draws spectrum data received from a
     * { @link  Visualizer.OnDataCaptureListener#onWaveFormDataCapture }
     */
    class VisualizerView extends View
    {
        private byte[] mBytes;
        private float[] mPoints;
        private Rect mRect = new Rect();

        private Paint mForePaint = new Paint();
        private int mSpectrumNum = 48;
        private boolean mFirst = true;

        public VisualizerView(Context context)
        {
            super(context);
            init();
        }

        private void init()
        {
            mBytes = null;

            mForePaint.setStrokeWidth(8f);
            mForePaint.setAntiAlias(true);
            mForePaint.setColor(Color.rgb(0, 128, 255));
        }

        public void updateVisualizer(byte[] fft)
        {
            if(mFirst )
            {
                mFirst = false;
            }

            // Make FFT transformation

            byte[] model = new byte[fft.length / 2 + 1];

            model[0] = (byte) Math.abs(fft[0]);
            for (int i = 2, j = 1; j< mSpectrumNum;)
            {
                model[j] = (byte) Math.hypot(fft[i]  , fft[i + 1]);
                i += 2;
                j++;

            }
            mBytes = model;


            invalidate();


        }

        @Override
        protected void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);

            if (mBytes == null)
            {
                return;
            }

            if (mPoints == null || mPoints.length < mBytes.length * 4)
            {
                mPoints = new float[mBytes.length * 4];
            }

            mRect.set(0, 0, getWidth(), getHeight());


            //Create Spectrum
            final int baseX = mRect.width()/mSpectrumNum;
            final int height = mRect.height();

            for (int i = 0; i < mSpectrumNum ; i++)
            {
                if (mBytes[i]  < 0)
                {
                    mBytes[i]  = 127;
                }

                final int xi = baseX*i + baseX/2;

                mPoints[i * 4] = xi;
                mPoints[i * 4 + 1] = height;

                mPoints[i * 4 + 2] = xi;
                mPoints[i * 4 + 3] = height - mBytes[i];

            }

            SendAveValue(mPoints, mSpectrumNum, height);

            canvas.drawLines(mPoints, mForePaint);
        }
    }

    //Get Average voltage value in certain frequency band
    private  void SendAveValue( float[] points,int spectrumNum, int height) {
        float SpectrumValue = 0;
        float[] SendMsg = new float[ BulbNum ];

        int num = spectrumNum / BulbNum;
        int index = 0;

        for(int i = 0 ; i < BulbNum ; i++ ){
            float sum = 0 ;
            for( int j = 0 ; j < num ; j++ ){

                SpectrumValue = height - points[index * 4 + 3];
                sum = sum + SpectrumValue;
                index++;

            }
            if ( sum != 0 ) {

                SendMsg[i] = sum / num;

            }
        }
        url = "http://192.168.0.14:8888/ECMusicIn.php?f0=" + SendMsg[0]+ "&f1=" + SendMsg[1] + "&f2=" + SendMsg[2]+ "&f3=" + SendMsg[3]+ "&f4=" + SendMsg[4]+ "&f5=" + SendMsg[5];
        new DownloadJsonTask().execute(url);


    }


    class DownloadJsonTask extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            // params comes from the execute() call: params[0] is the url.
            Log.d(TAG, url);
            InputStream inputStream = null;
            BufferedReader bufReader = null;
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();


                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.setChunkedStreamingMode(0);
                conn.setUseCaches(false);

                conn.connect();

                int response = conn.getResponseCode();
                if (response == 200) {
                    inputStream = conn.getInputStream();
                }

                bufReader = new BufferedReader(new InputStreamReader(inputStream));
                String x = bufReader.readLine();

                conn.disconnect();
                return null;


            } catch (IOException e) {
                return "";
            }

        }




    }

}
