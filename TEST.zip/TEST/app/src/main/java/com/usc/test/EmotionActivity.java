package com.usc.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class EmotionActivity extends Activity {
    private String text;
    private String emotion = "happy";
    private String audioFilePath;
    private String audioFileName;
    private File file;

    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emotion);
        TextView textView = (TextView) findViewById(R.id.textView);


        /*
            code for emotion detection
         */



        String path = Environment.getExternalStorageDirectory().getPath() + "/Music/" + emotion + "/";
        file = new File(path);
        File[] subFile = file.listFiles();
        List<String[]> subFilePath = new ArrayList<>();
        for (int i = 0; i < subFile.length; i++){

            subFilePath.add(new String[]{subFile[i].getAbsolutePath(), subFile[i].getName()});
        }
        Collections.shuffle(subFilePath);
        audioFilePath = subFilePath.get(0)[0];
        audioFileName = subFilePath.get(0)[1];




        if(emotion.equals("happy")) {
            text = "You are happy! Let's listen to " + audioFileName;
        }
        else if(emotion.equals("calm")) {
            text = "You feel calm? Find inner peace by listening to " + audioFileName;
        }
        textView.setText(text);


        //Switch to music play interface
        intent = new Intent(EmotionActivity.this, PlayActivity.class);
        intent.putExtra("audioFilePath", audioFilePath);
        intent.putExtra("audioFileName", audioFileName);
        Timer timer = new Timer();
        TimerTask task = new TimerTask(){
            @Override
            public void run(){
                startActivity(intent);
            }
        };
        timer.schedule(task, 1000*3);
    }
}
