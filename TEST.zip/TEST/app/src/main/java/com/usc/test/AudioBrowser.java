package com.usc.test;

import android.Manifest;
import android.app.ListActivity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;


public class AudioBrowser extends ListActivity {
	private Cursor cursor;
	private final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;



	//List all the songs
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_audio_browser);

		//For SDK=23, need USER GRANTS PERMISSIONS AT RUN-TIME
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
					!= PackageManager.PERMISSION_GRANTED) {

				// Should we show an explanation?
				if (shouldShowRequestPermissionRationale(
						Manifest.permission.READ_EXTERNAL_STORAGE)) {
					// Explain to the user why we need to read the contacts
				}

				requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
						MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
				// MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
				// app-defined int constant

				return;
			}
		}
		cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
		String[] displayFields = new String[]{MediaStore.Audio.Media.TITLE};
		int[] displayViews = new int[]{android.R.id.text1};

		setListAdapter(new SimpleCursorAdapter(this,
				android.R.layout.simple_list_item_1, cursor, displayFields,
				displayViews));

		Button emotionDetection = (Button) findViewById(R.id.emotionDetection);
		emotionDetection.setOnClickListener(emotionDetectionClick);

	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
		switch (requestCode) {
			case MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE: {
				if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					// Permission was granted!
					// Perform the action

					cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
					String[] displayFields = new String[]{MediaStore.Audio.Media.TITLE};
					int[] displayViews = new int[]{android.R.id.text1};

					setListAdapter(new SimpleCursorAdapter(this,
							android.R.layout.simple_list_item_1, cursor, displayFields,
							displayViews));

					Button emotionDetection = (Button) findViewById(R.id.emotionDetection);
					emotionDetection.setOnClickListener(emotionDetectionClick);
				} else {
					// Permission was denied
					// :(
					// Gracefully handle the denial
				}
				return;
			}

			// Add additional cases for other permissions you may have asked for
		}
	}

	private View.OnClickListener emotionDetectionClick = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent;
			intent = new Intent(AudioBrowser.this, EmotionActivity.class);
			startActivity(intent);
		}
	};

	@SuppressWarnings("deprecation")
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);

		if (cursor.moveToPosition(position)) {
			int fileColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
			int name = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
			String audioFilePath = cursor.getString(fileColumn);
			String audioFileName = cursor.getString(name);

			//Switch to music play interface
			Intent intent;
			intent = new Intent(AudioBrowser.this, PlayActivity.class);
			intent.putExtra("audioFilePath", audioFilePath);
			intent.putExtra("audioFileName", audioFileName);
			startActivity(intent);

		}


	}


}
